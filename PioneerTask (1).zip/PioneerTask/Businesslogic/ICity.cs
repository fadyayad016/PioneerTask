﻿using PioneerTask.Data;
using PioneerTask.Dtos;

namespace PioneerTask.Businesslogic
{
    public interface ICity
    {
        List<City> GetAllCities(int coutryId);
        CityDto AddCity(CityDto cityDto);
    }
}
