﻿using PioneerTask.Data;
using PioneerTask.Dtos;

namespace PioneerTask.Businesslogic
{
    public class CustomerService:ICustomer
    {
        private readonly ApplicationDbContext _context;

        public CustomerService(ApplicationDbContext context)
        {
            _context = context;
        }
        public List<Customer> GetAllCustomers()
        {
            var Customers= _context.Customers.ToList();
            return Customers;
        }
        public CustomerDto AddCustomer(CustomerDto customer)
        {
            try
            {
                if (customer.CityId == 0 || customer.CountryId == 0)
                {
                    throw new ArgumentException("CityId and CountryId cannot be zero.");
                }

                var cityExists = _context.Cities.Any(c => c.Id == customer.CityId);
                var countryExists = _context.Countries.Any(c => c.Id == customer.CountryId);

                if (!cityExists || !countryExists)
                {
                    throw new ArgumentException("City or Country does not exist.");
                }

                var customerEntity = new Customer
                {
                    Customername=customer.Customername,
                    CityId=customer.CityId, 
                    CountryId=customer.CountryId,
                    Phonenumber=customer.Phonenumber,   
                    Address=customer.Address,
                };

                _context.Customers.Add(customerEntity);
                _context.SaveChanges();

               customer.Id = customerEntity.Id; 

                return customer;
            }
            catch (Exception ex)
            {
                // Log the exception or handle it as appropriate for your application
                Console.WriteLine($"An error occurred while adding customer: {ex.Message}");
                return null;
            }
        }




    }
}
