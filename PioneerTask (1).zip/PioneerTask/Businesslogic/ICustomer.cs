﻿using PioneerTask.Data;
using PioneerTask.Dtos;

namespace PioneerTask.Businesslogic
{
    public interface ICustomer
    {
        List<Customer> GetAllCustomers();

        CustomerDto AddCustomer(CustomerDto customer);

    }
}
