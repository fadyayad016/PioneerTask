﻿using PioneerTask.Data;
using PioneerTask.Dtos;

namespace PioneerTask.Businesslogic
{
    public interface ICountry
    {
        List<Country> GetAllCountries();
        CoutryDto AddCountry(CoutryDto countryDto);
    }
}
