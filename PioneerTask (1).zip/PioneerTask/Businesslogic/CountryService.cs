﻿using PioneerTask.Data;
using PioneerTask.Dtos;

namespace PioneerTask.Businesslogic
{
    public class CountryService:ICountry
    {
        private readonly ApplicationDbContext _context;

        public CountryService(ApplicationDbContext context)
        {
            _context = context;
        }


        public List<Country> GetAllCountries()
        {
            var countries = _context.Countries.ToList();
            return countries;
        }
        public CoutryDto AddCountry(CoutryDto countryDto)
        {
            var countryEntity = new Country
            {
                CountryName = countryDto.CountryName
            };

            _context.Countries.Add(countryEntity);

            _context.SaveChanges();

            countryDto.Id = countryEntity.Id;

            return countryDto;
        }



    }
}
