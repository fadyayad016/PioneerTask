﻿using PioneerTask.Data;
using PioneerTask.Dtos;

namespace PioneerTask.Businesslogic
{
    public class CityServiece:ICity
    {
        private readonly ApplicationDbContext _context;

        public CityServiece(ApplicationDbContext context)
        {
            _context = context;
        }
        public List<City> GetAllCities(int coutryId)
        {
            var city = _context.Cities.Where(c=>c.CountryId==coutryId).ToList();
            return city;
        }
        public CityDto AddCity(CityDto cityDto)
        {
            try
            {
                if (cityDto.CountryId == 0)
                {
                    throw new ArgumentException("CountryId cannot be zero.");
                }

                var countryExists = _context.Countries.FirstOrDefault(c => c.Id == cityDto.CountryId);
                if (countryExists == null)
                {
                    throw new ArgumentException($"Country with ID {cityDto.CountryId} does not exist.");
                }

                var cityEntity = new City
                {
                    Cityname = cityDto.Cityname,
                    CountryId = cityDto.CountryId
                };

                _context.Cities.Add(cityEntity);
                _context.SaveChanges();

                
                cityDto.Id = cityEntity.Id;

                return cityDto;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred while adding city: {ex.Message}");
                return null;
            }
        }




    }
}
