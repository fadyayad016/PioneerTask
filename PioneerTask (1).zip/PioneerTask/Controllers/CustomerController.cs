﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PioneerTask.Businesslogic;
using PioneerTask.Data;
using PioneerTask.Dtos;

namespace PioneerTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomer _customerService;

        public CustomerController(ICustomer customerService)
        {
            _customerService = customerService;
        }

        [HttpPost]
        [Route("AddCustomer")]
        public IActionResult AddCustomer(CustomerDto customer)
        {
            var addedCustomr = _customerService.AddCustomer(customer);
            return Ok(addedCustomr);
        }
        [HttpGet]
        [Route("GetAllCustomers")]
        public IActionResult GetAllCustomers()
        {
            var Customers = _customerService.GetAllCustomers();
            return Ok(Customers);
        }
    }
}
