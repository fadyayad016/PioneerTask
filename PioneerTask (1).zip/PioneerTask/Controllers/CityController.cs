﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PioneerTask.Businesslogic;
using PioneerTask.Data;
using PioneerTask.Dtos;

namespace PioneerTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly ICity _CityService;

        public CityController(ICity cityService)
        {
            _CityService = cityService;
        }

        [HttpGet]
        [Route("GetAllCities")]
        public IActionResult GetAllCities(int coutryId)
        {
            var Cities = _CityService.GetAllCities(coutryId);
            return Ok(Cities);
        }
        [HttpPost]
        [Route("AddCity")]
        public IActionResult AddCity(CityDto city)
        {
            var addedCity = _CityService.AddCity(city);
            return Ok(addedCity);
        }


    }
}
