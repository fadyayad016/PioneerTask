﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PioneerTask.Businesslogic;
using PioneerTask.Data;
using PioneerTask.Dtos;
using System.Diagnostics.Metrics;

namespace PioneerTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly ICountry _countryService;

        public CountryController(ICountry countryService)
        {
            _countryService = countryService;
        }


        [HttpGet]
        [Route("GetAllcountry")]
        public IActionResult GetAllcountry()
        {
            var countries = _countryService.GetAllCountries();
            return Ok(countries);
        }

        [HttpPost]
        [Route("AddCountry")]
        public IActionResult AddCountry(CoutryDto country)
        {
            var addedCountry = _countryService.AddCountry(country);
            return Ok(addedCountry);
        }

    }
}
