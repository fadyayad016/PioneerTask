﻿using System.ComponentModel.DataAnnotations;

namespace PioneerTask.Dtos
{
    public class CoutryDto
    {
        public int Id { get; set; }
        [MaxLength(100)]
        public string? CountryName { get; set; }
    }
}
