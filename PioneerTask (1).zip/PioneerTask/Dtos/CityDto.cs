﻿using System.ComponentModel.DataAnnotations;

namespace PioneerTask.Dtos
{
    public class CityDto
    {
        public int Id { get; set; }
        [MaxLength(100)]
        public string? Cityname { get; set; }
        public int CountryId { get; set; }
    }
}
