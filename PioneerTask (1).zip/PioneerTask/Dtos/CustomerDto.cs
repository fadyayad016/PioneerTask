﻿using System.ComponentModel.DataAnnotations;

namespace PioneerTask.Dtos
{
    public class CustomerDto
    {
        public int Id { get; set; }
        [MaxLength(100)]
        public string? Customername { get; set; }
        public int CountryId { get; set; }
        public int CityId { get; set; }
        [MaxLength(100)]
        public string? Phonenumber { get; set; }
        [MaxLength(100)]
        public string? Address { get; set; }

    }
}
