﻿using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;

namespace PioneerTask.Data
{
    public class Country
    {
        public int Id { get; set; }
        [MaxLength(100)]
        public string? CountryName { get; set; }
        public ICollection<City> Cities { get; set; } 
        public ICollection<Customer> Customers { get; set; }

    }
}
