﻿using System.ComponentModel.DataAnnotations;

namespace PioneerTask.Data
{
    public class City
    {

        public int Id { get; set; }
        [MaxLength(100)]
        public string? Cityname { get; set; }
        public int CountryId { get; set; }
        public Country Country { get; set; }
        public ICollection<Customer> Customers { get; set; }

    }
}
