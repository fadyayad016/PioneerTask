﻿using System.ComponentModel.DataAnnotations;
using System.Reflection.Metadata;

namespace PioneerTask.Data
{
    public class Customer
    {
        public int Id { get; set; }
        [MaxLength(100)]
        public string? Customername { get; set; } 
        public int CountryId { get; set; } 
        public int CityId { get; set; }
        [MaxLength(100)]
        public string? Phonenumber { get; set; }
        [MaxLength(100)]
        public string? Address { get; set; }
        public Country Country { get; set; }
        public City City { get; set; }
    }
}
